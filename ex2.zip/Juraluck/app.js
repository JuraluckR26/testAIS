require('dotenv').config()
const db = require('./config/database')
const express = require('express') 
const app = express()

app.use(express.json())


app.post("/genPass", async (req, res) => {
    try{
        let listPass = []
        for(let i = 0; i < 10000; i++){
            const numPass = String(i).padStart(5, '0')
            const fullPass = numPass.slice(0, 3) + "ABC" + numPass.slice(3)
            console.log(fullPass)
            listPass.push([fullPass])
        }
        console.log(listPass)
        const sql = "INSERT INTO genpass (pass) VALUES ?"
        db.query(sql, [listPass], (error) => {
            if (error) {
                console.error('query error:', error)
                return
            } else {
                res.status(400).json("gen password success")
            }
        })

    } catch(error) {
        console.log(error)
    }
})

module.exports = app